package com.example.e_commerce_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class orderConfirmation extends AppCompatActivity {

    Button oc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirmation);

        oc=findViewById(R.id.btn_back_to_home);

        oc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(orderConfirmation.this, HomePage.class);
                // Start the HomePage activity
                startActivity(intent);
            }
        });
    }
}