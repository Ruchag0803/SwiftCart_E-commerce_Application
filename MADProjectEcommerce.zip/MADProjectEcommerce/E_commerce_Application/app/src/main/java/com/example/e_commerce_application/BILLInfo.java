package com.example.e_commerce_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class BILLInfo extends AppCompatActivity {

    private DatabaseReference categoriesRef;
    private DatabaseReference shoppedRef;
    private LinearLayout layoutBill;
    private double total = 0.0;
String pn="";
String tp="";
    Button proceedToPay;
    TextView totalBillValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billinfo);
        proceedToPay=findViewById(R.id.proceedToPay);

        proceedToPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BILLInfo.this, payment.class);
                // Start the HomePage activity
                startActivity(intent);
            }
        });
        // Initialize Firebase Database references
        categoriesRef = FirebaseDatabase.getInstance().getReference().child("categories");
        shoppedRef = FirebaseDatabase.getInstance().getReference().child("shopped");

        // Initialize layout
        layoutBill = findViewById(R.id.layout_bill);
        totalBillValue=findViewById(R.id.total);

        // Fetch product details and calculate total
        fetchShoppedItems();
    }


    private void fetchShoppedItems() {
        shoppedRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot shoppedSnapshot : dataSnapshot.getChildren()) {
                        String productId = shoppedSnapshot.getValue(String.class);
                        fetchProductDetails(productId);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }

    private void fetchProductDetails(String productId) {
        categoriesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot categorySnapshot : dataSnapshot.getChildren()) {
                        if (categorySnapshot.hasChild(productId)) {
                            String productName = categorySnapshot.child(productId).child("name").getValue(String.class);
                            Double productPrice = categorySnapshot.child(productId).child("price").getValue(Double.class);
                            addProductToBill(productName, productPrice); // Add product to bill layout
                            break; // No need to check other categories
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }


    private void addProductToBill(String productName, double productPrice) {
        // Create TextViews for product name and price
        TextView textViewProductName = new TextView(this);
        textViewProductName.setText(productName);

        pn=pn+" \n"+productName;

        TextView textViewProductPrice = new TextView(this);
        textViewProductPrice.setText("Rs. " + String.valueOf(productPrice));

        // Add TextViews to the layout
        layoutBill.addView(textViewProductName);
        layoutBill.addView(textViewProductPrice);

        // Update total and display
        total += productPrice;
        String t = Double.toString(total);
        totalBillValue.setText("Rs. " + t);

        // After displaying total bill, remove the data in 'shopped' node
        clearShoppedData();
    }


    private void clearShoppedData() {
        shoppedRef.removeValue(); // Removes all data under 'shopped' node
    }

}
