package com.example.e_commerce_application;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class toys extends AppCompatActivity {

    private List<String> cartItems;
    private DatabaseReference shoppedRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toys);

        // Initialize cartItems list
        cartItems = new ArrayList<>();

        // Get a reference to the 'shopped' category in the Firebase Database
        shoppedRef = FirebaseDatabase.getInstance().getReference().child("shopped");

        ImageView homeImageView = findViewById(R.id.home);
        homeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate to the HomePage activity
                Intent intent = new Intent(toys.this, HomePage.class);
                // Start the HomePage activity
                startActivity(intent);
            }
        });

        // Find all "Add to Cart" buttons
        Button addToCartButton1 = findViewById(R.id.t1);
        Button addToCartButton2 = findViewById(R.id.t2);
        Button addToCartButton3 = findViewById(R.id.t3);
        Button addToCartButton4 = findViewById(R.id.t4);

        // Common OnClickListener for all "Add to Cart" buttons
        View.OnClickListener addToCartClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the ID of the clicked button
                String buttonId = getResources().getResourceEntryName(v.getId());
                // Add button ID to cartItems list
                cartItems.add(buttonId);
                Toast.makeText(toys.this, "Product added to cart", Toast.LENGTH_LONG).show();

                // Save the clicked button ID to the 'shopped' category in Firebase
                saveToShopped(buttonId);
            }
        };

        // Set OnClickListener for all "Add to Cart" buttons
        addToCartButton1.setOnClickListener(addToCartClickListener);
        addToCartButton2.setOnClickListener(addToCartClickListener);
        addToCartButton3.setOnClickListener(addToCartClickListener);
        addToCartButton4.setOnClickListener(addToCartClickListener);

        // Find the "Payment" button
        ImageView paymentButton = findViewById(R.id.payment);

        // Set OnClickListener for the "Payment" button
        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the PaymentActivity when "Payment" button is clicked
                Intent intent = new Intent(toys.this, BILLInfo.class);
                // Pass the list of product IDs to the PaymentActivity
                intent.putStringArrayListExtra("productIds", new ArrayList<>(cartItems));
                startActivity(intent);
            }
        });
    }

    private void saveToShopped(String buttonId) {
        // Save the button ID under 'shopped' category in Firebase
        shoppedRef.push().setValue(buttonId);
    }
}
