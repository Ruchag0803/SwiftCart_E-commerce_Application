package com.example.e_commerce_application;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.example.e_commerce_application.databinding.ActivityHomePageBinding;

public class HomePage extends AppCompatActivity {
    ActivityHomePageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize the clothes ImageButton using view binding
        ImageButton clothesButton = binding.clothes;
        ImageButton foodButton = binding.food;
        ImageButton kitchenButton = binding.kitchen;
        ImageButton skincareButton = binding.skincare;
        ImageButton artButton = binding.art;
        ImageButton toysButton = binding.toy;

        // Set click listener for the clothes button
        clothesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the ClothesActivity when the clothes button is clicked
                startActivity(new Intent(HomePage.this, clothes.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });


        foodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the ClothesActivity when the clothes button is clicked
                startActivity(new Intent(HomePage.this, food.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });


        kitchenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the ClothesActivity when the clothes button is clicked
                startActivity(new Intent(HomePage.this, kitchenware.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });

        skincareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, skincare.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });


        artButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, art.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });

        toysButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, toys.class));
                // Finish the current activity to prevent going back to it when pressing back
                finish();
            }
        });

    }
}
